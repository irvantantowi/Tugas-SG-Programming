alas = input('Masukkan alas: ')
tinggi = input('Masukkan tinggi: ');
Luassegitiga = (alas * tinggi) / 2;

disp("luas : " +Luassegitiga)

sisi1 = input('Masukkan sisi 1: ');
sisi2 = input('Masukkan sisi 2: ');
sisi3 = input('Masukkan sisi 3: ');
Kelilingsegitiga = sisi1 + sisi2 + sisi3;
disp("keliling : " +Kelilingsegitiga)