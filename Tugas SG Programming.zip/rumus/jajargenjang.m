alas = input('Masukkan alas: ');
sisimiring = input('Masukkan sisi miring: ');
tinggi = input('Masukkan tinggi: ');
Luasjajargenjang= alas * tinggi;
Kelilingjajargenjang = 2 * (alas + sisimiring);

disp("luas : " +Luasjajargenjang)
disp("keliling : " +Kelilingjajargenjang)