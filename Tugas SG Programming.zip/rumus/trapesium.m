sisibawah = input('Masukkan sisi bawah : '); 
sisiatas = input('Masukkan sisi atas : '); 
sisikanan = input('Masukkan sisi kanan: '); 
sisikiri = input('Masukkan sisi kiri: ');
tinggi = input('Masukkan tinggi: ');
Luastrapesium= (sisibawah + sisiatas) * tinggi / 2;
Kelilingtrapesium = sisibawah + sisiatas + sisikiri + sisikanan;

disp("luas : " +Luastrapesium)
disp("keliling : " +Kelilingtrapesium)