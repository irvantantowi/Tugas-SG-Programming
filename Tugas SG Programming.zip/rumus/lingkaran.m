pi = 3.14;
jarijari = input('Masukkan jari jari : ');
Luaslingkaran = pi * jarijari * jarijari;
Kelilinglingkaran = 2 * pi * jarijari;

disp("luas : " +Luaslingkaran)
disp("keliling : " +Kelilinglingkaran)