sisikiriatas = input('Masukkan sisi kiri atas : '); 
sisikananatas = input('Masukkan sisi kanan atas : '); 
sisikiribawah = input('Masukkan sisi kiri bawah: '); 
sisikananbawah = input('Masukkan sisi kanan bawah: ');
diagonal1 = input('Masukkan diagonal 1 : ');
diagonal2 = input('Masukkan diagonal 2 : ');
Luaslayanglayang = (diagonal1 * diagonal2) / 2;
Kelilinglayanglayang = sisikiriatas + sisikananatas + sisikiribawah + sisikananbawah;

disp("keliling : " +Kelilinglayanglayang)
disp("luas : " +Luaslayanglayang)